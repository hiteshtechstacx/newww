import React, { useEffect, useState } from 'react';
import { Star, Clock, Calendar, Film, Users, Video } from 'lucide-react';
import { Header } from '../components/common/Header';
import { MovieRecommendations } from '../components/movies/MovieRecommendations';
import { getMovieDetails } from '../api/omdb';
import type { MovieDetails as MovieDetailsType } from '../types/movie';

interface MovieDetailsProps {
  id: string;
  onClose: () => void;
}

export function MovieDetailsPage({ id, onClose }: MovieDetailsProps) {
  const [movie, setMovie] = useState<MovieDetailsType | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovie = async () => {
      try {
        const details = await getMovieDetails(id);
        setMovie(details);
      } catch (error) {
        console.error('Error fetching movie details:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMovie();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Header />
        <div className="flex justify-center items-center h-[calc(100vh-64px)]">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-yellow-400 border-t-transparent"></div>
        </div>
      </div>
    );
  }

  if (!movie) return null;

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          {/* Hero Section */}
          <div className="relative h-[400px]">
            <img
              src={movie.Poster !== 'N/A' ? movie.Poster : 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=1200'}
              alt={movie.Title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end">
              <div className="p-8 text-white">
                <h1 className="text-4xl font-bold mb-2">{movie.Title}</h1>
                <div className="flex items-center gap-4 text-sm">
                  <span className="flex items-center gap-1">
                    <Star className="text-yellow-400 fill-yellow-400" size={16} />
                    {movie.imdbRating}
                  </span>
                  <span>{movie.Year}</span>
                  <span>{movie.Runtime}</span>
                  <span>{movie.Rated}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main Content */}
              <div className="lg:col-span-2 space-y-6">
                <div>
                  <h2 className="text-2xl font-bold mb-4">Overview</h2>
                  <p className="text-gray-700 leading-relaxed">{movie.Plot}</p>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                      <Users size={18} />
                      Cast
                    </h3>
                    <p className="text-gray-600 mt-1">{movie.Actors}</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                      <Video size={18} />
                      Director
                    </h3>
                    <p className="text-gray-600 mt-1">{movie.Director}</p>
                  </div>
                </div>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="font-semibold text-gray-900 mb-4">Movie Info</h3>
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Calendar size={18} className="text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-600">Release Date</p>
                        <p className="font-medium">{movie.Released}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock size={18} className="text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-600">Runtime</p>
                        <p className="font-medium">{movie.Runtime}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Film size={18} className="text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-600">Genre</p>
                        <p className="font-medium">{movie.Genre}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {movie.Ratings && movie.Ratings.length > 0 && (
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-4">Ratings</h3>
                    <div className="space-y-3">
                      {movie.Ratings.map((rating) => (
                        <div key={rating.Source} className="flex justify-between items-center">
                          <span className="text-gray-600">{rating.Source}</span>
                          <span className="font-medium">{rating.Value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <MovieRecommendations
          genre={movie.Genre.split(',')[0]}
          onMovieClick={(movie) => window.location.href = `/movie/${movie.imdbID}`}
        />
      </main>
    </div>
  );
}